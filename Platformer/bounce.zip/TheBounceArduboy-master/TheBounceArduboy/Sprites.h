// Joshimuz 2016

#ifndef _SPRITES_h
#define _SPRITES_h

#include <avr/pgmspace.h>

extern const unsigned char titleScreen[];

extern const unsigned char playButton[];

extern const unsigned char configButton[];

extern const unsigned char abButtons[];

extern const unsigned char buttonBase[];

extern const unsigned char menuBall[];

extern const unsigned char rocket[];

extern const unsigned char rocketFire[];

extern const unsigned char theEnd[];

#endif

