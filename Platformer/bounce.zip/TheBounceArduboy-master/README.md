The Bounce: Arduboy Edition

Game uses Arduboy2 library as well as ArduboyTones library, both of which can be found in the Arduino Library Manager.
