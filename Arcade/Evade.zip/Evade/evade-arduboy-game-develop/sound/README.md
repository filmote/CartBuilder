# audio_module
Source code for a demo app that plays the music for each score

# midi2tones
A tool for the Arduboy2.tones library that converts  MIDI to `.tones()`.

# miditones
A tool for the Arduboy.ArduTunes library that converts  MIDI to data for `playScore()`.

# songs
Where the source MIDI & reason files are