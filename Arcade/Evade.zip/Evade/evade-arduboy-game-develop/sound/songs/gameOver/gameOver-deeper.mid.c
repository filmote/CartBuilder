// Playtune bytestream for file "gameOver-deeper.mid.mid" created by MIDITONES V1.14 on Tue Nov 22 16:11:12 2016
// command line: miditones gameOver-deeper.mid 
const unsigned char PROGMEM score [] = {
// Transport
0x90,41, 0,200, 0x90,44, 2,88, 0x90,49, 0,200, 0x90,48, 3,232, 0x80, 0xf0};
// This score contains 18 bytes, and 1 tone generator is used.
