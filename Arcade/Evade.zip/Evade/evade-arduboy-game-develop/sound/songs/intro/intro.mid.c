// Playtune bytestream for file "title.mid.mid" created by MIDITONES V1.14 on Sun Nov 13 11:01:26 2016
// command line: miditones title.mid 
const unsigned char PROGMEM score [] = {
// Transport
0x90,63, 0,100, 0x90,65, 0,100, 0x90,67, 0,100, 0x90,70, 1,144, 0x80, 0xf0};
// This score contains 18 bytes, and 1 tone generator is used.
