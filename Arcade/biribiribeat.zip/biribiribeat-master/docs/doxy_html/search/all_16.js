var searchData=
[
  ['x_488',['x',['../structcoord__2d.html#a2ab5d141f019c4f3fc1743066669c01f',1,'coord_2d']]],
  ['x_5fpos_489',['x_pos',['../classentity.html#a379e3ada082033a8dc96d6ac9315cee3',1,'entity']]],
  ['x_5fstart_490',['x_start',['../structmenu__data.html#a050bb469fa24574eaf0448dca004777e',1,'menu_data']]]
];
