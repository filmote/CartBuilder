var searchData=
[
  ['init_586',['init',['../classnavi.html#a066c43aae2c3f9c6164f55711ae2fa19',1,'navi::init(int8_t x_pos, int8_t y_pos, navi_expression_e expression)'],['../classnavi.html#a9779ae04fb6240e245f508085bf47569',1,'navi::init(int8_t x_pos, int8_t y_pos, navi_expression_e expression, uint8_t ticks_per_beat)'],['../classnote.html#a9f32007bddfeadeb8763f6c9ff0ecc24',1,'note::init()']]]
];
