var searchData=
[
  ['base_5fstate_496',['base_state',['../classbase__state.html',1,'']]]
];
