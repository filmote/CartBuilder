var searchData=
[
  ['data_664',['data',['../classnotelist.html#a1adc5dfbc9a7ee05328fb6cf9338f3da',1,'notelist']]],
  ['desc_665',['desc',['../structentry__data.html#aa90dde8e6ca2b2e161fa3b85c3430c6b',1,'entry_data']]],
  ['diff_5fdesc_5fhs_666',['diff_desc_hs',['../menus_8cpp.html#a19c2ce0deeb56a2b0bc51a4e3536e7ed',1,'menus.cpp']]],
  ['diff_5fentries_667',['diff_entries',['../menus_8cpp.html#a77b9e207a809590a23cb527137c7d37b',1,'menus.cpp']]],
  ['diff_5ftext_5f1_668',['diff_text_1',['../menus_8cpp.html#a87a8f8af7813839de863fe52ec826439',1,'menus.cpp']]],
  ['diff_5ftext_5f2_669',['diff_text_2',['../menus_8cpp.html#ab41a80a9527251a52ce9263f532c6e59',1,'menus.cpp']]],
  ['diff_5ftext_5f3_670',['diff_text_3',['../menus_8cpp.html#a9988446c84de96b9c0d871e1294fc989',1,'menus.cpp']]],
  ['downarrow_671',['downArrow',['../sprites__buttons_8cpp.html#acc0e1ecd98dcf5fb5c5e88516289073f',1,'sprites_buttons.cpp']]],
  ['downarrowfilled_672',['downArrowFilled',['../sprites__buttons_8cpp.html#ad3698fdb307ccfe7f7459268a3a4ad26',1,'sprites_buttons.cpp']]]
];
