var indexSectionsWithContent =
{
  0: "_abcdefghilmnopqrstuvwxy~",
  1: "bcefgmnoprs",
  2: "efgmnrs",
  3: "_abcdfgilmnoprstuw~",
  4: "_abcdefghilmnoprstuvxy",
  5: "o",
  6: "dgmnt",
  7: "cefghimnprsuv",
  8: "cefghlmnpqstw",
  9: "b"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "defines",
  9: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Macros",
  9: "Pages"
};

