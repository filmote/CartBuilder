var searchData=
[
  ['quarter_5fnote_5fticks_329',['QUARTER_NOTE_TICKS',['../squawk__defines_8h.html#a57a899b7c952d4394b709b61acd07c15',1,'squawk_defines.h']]]
];
