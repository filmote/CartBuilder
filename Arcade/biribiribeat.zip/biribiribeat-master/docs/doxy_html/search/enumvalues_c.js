var searchData=
[
  ['vertical_915',['VERTICAL',['../menu_8h.html#a8177da8f92fcd6e558a01ef3aef587bda1a88641fcd39f2ed3e58a18526e97138',1,'menu.h']]]
];
