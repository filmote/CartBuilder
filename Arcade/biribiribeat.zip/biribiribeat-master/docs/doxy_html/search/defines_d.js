var searchData=
[
  ['whole_5fnote_5fticks_970',['WHOLE_NOTE_TICKS',['../squawk__defines_8h.html#aa126fc7915d4d881aaa33f4df4bb77fc',1,'squawk_defines.h']]]
];
