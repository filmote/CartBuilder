var searchData=
[
  ['navi_5fexpression_5fe_879',['navi_expression_e',['../navi_8h.html#a51d974a9b98fef881c034f8704ce3386',1,'navi.h']]]
];
