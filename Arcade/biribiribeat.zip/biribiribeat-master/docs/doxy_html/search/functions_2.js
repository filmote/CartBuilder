var searchData=
[
  ['begin_559',['begin',['../class_squawk_synth.html#afcd1a2587d3be2c5e9c084c1815e4e9f',1,'SquawkSynth']]]
];
