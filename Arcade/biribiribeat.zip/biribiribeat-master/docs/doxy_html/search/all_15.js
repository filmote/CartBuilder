var searchData=
[
  ['whole_5fnote_5fticks_486',['WHOLE_NOTE_TICKS',['../squawk__defines_8h.html#aa126fc7915d4d881aaa33f4df4bb77fc',1,'squawk_defines.h']]],
  ['write_487',['write',['../class_font4x6.html#ae496d7d3b6fcd0fa67f7a384fe0a5720',1,'Font4x6']]]
];
