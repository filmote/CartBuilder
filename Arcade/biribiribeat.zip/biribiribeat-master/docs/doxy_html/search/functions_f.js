var searchData=
[
  ['tempo_5freset_629',['tempo_reset',['../class_squawk_synth.html#ae389f08cbe7290ccefd973d4395f8545',1,'SquawkSynth']]],
  ['tempo_5fup_630',['tempo_up',['../class_squawk_synth.html#a3883e742d66260e22ed258656892720e',1,'SquawkSynth']]]
];
